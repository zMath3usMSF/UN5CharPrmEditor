![MainBackground](Resources/MainBackground.png)
# About
This tool aims to edit the fight parameters of the characters in the game Naruto Shippuden: Ultimate Ninja 5. It supports only the European version and also supports modified versions such as Naruto Shippuden: Ultimate Ninja 5+.<br>
<br>
You can obtain it by going to the release section of this page. If you encounter any bugs, please remember to report them in the issues section.

